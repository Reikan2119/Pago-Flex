package com.example.pagoflex.model

enum class RolUsuario(val etiqueta: String) {
    USUARIO_FINAL("Usuario Final"),
    AGENTE("Agente PagoFlex"),
    EJECUTIVO("Ejecutivo de Empresa")
}

enum class MedioPago(val etiqueta: String) {
    DEBITO("Tarjeta de Débito"),
    CREDITO("Tarjeta de Crédito"),
    TRANSFERENCIA("Transferencia"),
    SIMULADO("Pago Simulado")
}

data class PagoFlexUiState(
    val nombreLogin: String = "",
    val errorNombreLogin: String? = null,
    val rolSeleccionado: RolUsuario? = null,
    val errorRolLogin: String? = null,

    val sesionIniciada: Boolean = false,
    val usuarioActual: Usuario? = null,

    val compromisos: List<Compromiso> = emptyList(),
    val empresas: List<EmpresaCliente> = emptyList(),

    val medioPagoSeleccionado: MedioPago = MedioPago.SIMULADO,
    val procesandoPago: Boolean = false,
    val errorPago: String? = null,
    val pagoExitoso: Boolean = false,

    val motivoReporte: String = "",
    val comentarioReporte: String = "",
    val errorReporte: String? = null,
    val reporteExitoso: Boolean = false
)