package com.example.pagoflex.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.pagoflex.model.RolUsuario
import com.example.pagoflex.ui.components.CampoTextoPagoFlex
import com.example.pagoflex.viewmodel.PagoFlexViewModel

@Composable
fun LoginSimuladoScreen(
    viewModel: PagoFlexViewModel,
    onLoginSuccess: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "PagoFlex Companion",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 32.dp).align(Alignment.CenterHorizontally)
        )

        CampoTextoPagoFlex(
            valor = uiState.nombreLogin,
            etiqueta = "Nombre de Usuario",
            onValorCambia = { viewModel.onNombreLoginCambia(it) },
            mensajeError = uiState.errorNombreLogin
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Seleccione su perfil:",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Column(modifier = Modifier.selectableGroup()) {
            RolUsuario.entries.forEach { rol ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = uiState.rolSeleccionado == rol,
                        onClick = { viewModel.onRolCambia(rol) }
                    )
                    Text(
                        text = rol.etiqueta,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }

        if (uiState.errorRolLogin != null) {
            Text(
                text = uiState.errorRolLogin!!,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                if (viewModel.onIntentarLogin()) {
                    onLoginSuccess()
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text("Ingresar")
        }
    }
}