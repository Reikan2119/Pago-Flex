package com.example.pagoflex.viewmodel

import androidx.lifecycle.ViewModel
import com.example.pagoflex.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class PagoFlexViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(PagoFlexUiState())
    val uiState: StateFlow<PagoFlexUiState> = _uiState.asStateFlow()

    init {
        cargarDatosSimulados()
    }

    fun onNombreLoginCambia(nombre: String) {
        _uiState.update { it.copy(nombreLogin = nombre, errorNombreLogin = null) }
    }

    fun onRolCambia(rol: RolUsuario) {
        _uiState.update { it.copy(rolSeleccionado = rol, errorRolLogin = null) }
    }

    fun onIntentarLogin(): Boolean {
        val estado = _uiState.value

        val errorNombre = if (estado.nombreLogin.isBlank()) "El nombre es obligatorio" else null
        val errorRol = if (estado.rolSeleccionado == null) "Debes seleccionar un perfil" else null

        if (errorNombre != null || errorRol != null) {
            _uiState.update {
                it.copy(errorNombreLogin = errorNombre, errorRolLogin = errorRol)
            }
            return false
        }

        _uiState.update { it.copy(sesionIniciada = true) }
        return true
    }

    fun onMedioPagoCambia(medio: MedioPago) {
        _uiState.update { it.copy(medioPagoSeleccionado = medio, errorPago = null, pagoExitoso = false) }
    }

    fun onPagarCompromiso(compromisoAPagar: Compromiso) {
        val estado = _uiState.value


        val compromisosMismaEmpresa = estado.compromisos.filter {
            it.idEmpresa == compromisoAPagar.idEmpresa && (it.idEstadoCompromiso == 1 || it.idEstadoCompromiso == 2)
        }

        val compromisoMasAntiguo = compromisosMismaEmpresa.minByOrNull { it.idCompromiso }

        val errorPago = if (compromisoAPagar.idEstadoCompromiso == 4 || compromisoAPagar.idEstadoCompromiso == 5) {
            "No puedes pagar un compromiso en revisión o anulado." // RN-08 y RN-09
        } else if (compromisoMasAntiguo != null && compromisoMasAntiguo.idCompromiso != compromisoAPagar.idCompromiso) {
            "Debes pagar tu compromiso más antiguo primero." // RN-04
        } else {
            null
        }

        if (errorPago != null) {
            _uiState.update { it.copy(errorPago = errorPago, pagoExitoso = false) }
        } else {
            val nuevaLista = estado.compromisos.map {
                if (it.idCompromiso == compromisoAPagar.idCompromiso) {
                    it.copy(idEstadoCompromiso = 3)
                } else {
                    it
                }
            }

            _uiState.update {
                it.copy(
                    compromisos = nuevaLista,
                    pagoExitoso = true,
                    errorPago = null
                )
            }
        }
    }

    fun onLimpiarPago() {
        _uiState.update { it.copy(errorPago = null, pagoExitoso = false, medioPagoSeleccionado = MedioPago.SIMULADO) }
    }

    private fun cargarDatosSimulados() {
        val empresasFicticias = listOf(
            EmpresaCliente(1, "EC-01", "Altos del Maipo", 8500),
            EmpresaCliente(6, "EC-06", "Club Los Halcones", 2000),
            EmpresaCliente(8, "EC-08", "Plaza Oriente", 7500)
        )

        val compromisosFicticios = listOf(
            Compromiso(101, "CP-2026-0101", 1, 8, "Arriendo departamento octubre", "10/12", 520000, "10-10-2026", 1),
            Compromiso(102, "CP-2026-0102", 1, 6, "Cuota social octubre", "10/12", 15000, "05-10-2026", 2)
        )

        _uiState.update {
            it.copy(
                empresas = empresasFicticias,
                compromisos = compromisosFicticios,
                sesionIniciada = true
            )
        }
    }
}